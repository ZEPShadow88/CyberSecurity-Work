awk -F" " '{print $1, $2, $5, $6}' 0312_Dealer_schedule | egrep Billy | egrep 05


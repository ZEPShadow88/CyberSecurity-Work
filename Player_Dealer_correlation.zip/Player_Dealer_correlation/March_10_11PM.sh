awk -F" " '{print $1, $2, $5, $6}' 0310_Dealer_schedule | egrep Billy | egrep 11


#!/bin/bash

cat $1_Dealer_schedule | awk -F" " '{print $1, $2, '$3', '$4'}' | grep "$2"

#run command by sh roulette_dealer_finder_by_time_and_game.sh DATE TIME ARGUMENT

